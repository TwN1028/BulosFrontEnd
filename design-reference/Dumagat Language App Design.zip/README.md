
  # Dumagat Language App Design

  This is a code bundle for Dumagat Language App Design. The original project is available at https://www.figma.com/design/fRdD5ThatpMpf7aZNu1IW4/Dumagat-Language-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  