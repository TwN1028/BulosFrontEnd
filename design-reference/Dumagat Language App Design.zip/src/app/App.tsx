import { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  Mic, Globe, Wifi, WifiOff, Battery, Home, Languages,
  BookOpen, Clock, Volume2, ChevronRight,
  ArrowLeftRight, ArrowLeft, Zap, Check, Copy,
  Share2, RefreshCw, Pause, Play, Square,
  Search, X, ChevronDown, Trash2, Sun,
  Bell, Info, Shield, HelpCircle, Settings, AlertCircle,
} from "lucide-react";

// ─── TYPES ───────────────────────────────────────────────────────────────────

type Screen =
  | "splash" | "home" | "speech" | "translation"
  | "textTranslation" | "tts" | "dictionary"
  | "history" | "settings";

interface HistoryItem { id: number; date: string; time: string; from: string; to: string; source: string; result: string; }

// ─── CONSTANTS ───────────────────────────────────────────────────────────────

const LANGS = ["Bulos", "Filipino", "English"];
const WAVE_HEIGHTS = [8, 16, 28, 12, 24, 36, 10, 22, 32, 14, 26, 36, 8, 20, 30, 12, 18, 28, 10, 24];

const WORDS = [
  { id: 1, bulos: "Danum", filipino: "Tubig", english: "Water", pronunciation: "DA-num", example: "Kailangan natin ng danum para mabuhay.", englishEx: "We need water to survive." },
  { id: 2, bulos: "Balay", filipino: "Bahay", english: "House / Home", pronunciation: "BA-lay", example: "Ang aming balay ay malapit sa bundok.", englishEx: "Our home is near the mountain." },
  { id: 3, bulos: "Ama", filipino: "Ama / Tatay", english: "Father", pronunciation: "A-ma", example: "Si ama ay magsasaka at mangingisda.", englishEx: "Father is a farmer and fisherman." },
  { id: 4, bulos: "Ina", filipino: "Ina / Nanay", english: "Mother", pronunciation: "I-na", example: "Si ina ay nagmamahal sa aming lahat.", englishEx: "Mother loves all of us dearly." },
  { id: 5, bulos: "Gubat", filipino: "Kagubatan", english: "Forest", pronunciation: "GU-bat", example: "Maraming halaman at hayop sa aming gubat.", englishEx: "There are many plants and animals in our forest." },
  { id: 6, bulos: "Dagat", filipino: "Dagat", english: "Sea / Ocean", pronunciation: "DA-gat", example: "Malawak at malalim ang dagat ng aming lupain.", englishEx: "The sea of our land is vast and deep." },
  { id: 7, bulos: "Bundok", filipino: "Bundok", english: "Mountain", pronunciation: "BUN-dok", example: "Paboritong puntahan ng aming tribo ang bundok.", englishEx: "The mountain is a favorite place of our tribe." },
  { id: 8, bulos: "Sinag", filipino: "Liwanag / Sikat ng Araw", english: "Sunlight / Glow", pronunciation: "SI-nag", example: "Mainit ang sinag ng araw ngayon.", englishEx: "The sunlight is warm today." },
  { id: 9, bulos: "Manuk", filipino: "Ibon / Manok", english: "Bird / Fowl", pronunciation: "MA-nuk", example: "Ang manuk ay lumilipad nang mataas sa langit.", englishEx: "The bird flies high in the sky." },
  { id: 10, bulos: "Utud", filipino: "Kapatid", english: "Sibling / Brother", pronunciation: "U-tud", example: "Lagi kaming magkasama ng aking utud.", englishEx: "My sibling and I are always together." },
  { id: 11, bulos: "Lupa", filipino: "Lupa / Lupain", english: "Earth / Land", pronunciation: "LU-pa", example: "Ang lupa ng aming ninuno ay sagrado at banal.", englishEx: "Our ancestors' land is sacred and holy." },
  { id: 12, bulos: "Ulap", filipino: "Ulap", english: "Cloud", pronunciation: "U-lap", example: "Puting ulap ang lumulutang sa aming langit.", englishEx: "White clouds float in our sky." },
];

const HISTORY_INITIAL: HistoryItem[] = [
  { id: 1, date: "July 6, 2026", time: "10:23 AM", from: "Bulos", to: "Filipino", source: "Danum ang buhay ng lahat ng nilalang", result: "Ang tubig ay buhay ng lahat ng nilalang" },
  { id: 2, date: "July 6, 2026", time: "09:15 AM", from: "Filipino", to: "Bulos", source: "Kumain na tayo ng almusal", result: "Mangan na kita sa buntag" },
  { id: 3, date: "July 5, 2026", time: "03:45 PM", from: "Bulos", to: "English", source: "Balay ng aming ama sa bundok", result: "Our father's home in the mountain" },
  { id: 4, date: "July 5, 2026", time: "11:30 AM", from: "English", to: "Bulos", source: "Good morning, everyone", result: "Maayong buntag sa tanan" },
  { id: 5, date: "July 4, 2026", time: "04:20 PM", from: "Bulos", to: "Filipino", source: "Bundok at dagat ng aming lupa", result: "Bundok at dagat ng aming lupain" },
];

// ─── CULTURAL PATTERN ────────────────────────────────────────────────────────

function CulturalPattern({ opacity = 0.12, patternId = "dp-main" }: { opacity?: number; patternId?: string }) {
  return (
    <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg" style={{ opacity }}>
      <defs>
        <pattern id={patternId} x="0" y="0" width="52" height="52" patternUnits="userSpaceOnUse">
          <polygon points="26,4 48,26 26,48 4,26" fill="none" stroke="currentColor" strokeWidth="1.5" />
          <polygon points="26,14 38,26 26,38 14,26" fill="none" stroke="currentColor" strokeWidth="1" />
          <circle cx="26" cy="26" r="2.5" fill="currentColor" />
          <line x1="26" y1="4" x2="26" y2="14" stroke="currentColor" strokeWidth="0.8" />
          <line x1="48" y1="26" x2="38" y2="26" stroke="currentColor" strokeWidth="0.8" />
          <line x1="26" y1="48" x2="26" y2="38" stroke="currentColor" strokeWidth="0.8" />
          <line x1="4" y1="26" x2="14" y2="26" stroke="currentColor" strokeWidth="0.8" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#${patternId})`} />
    </svg>
  );
}

// ─── STATUS BAR ──────────────────────────────────────────────────────────────

function StatusBar({ isOffline }: { isOffline: boolean }) {
  return (
    <div className="flex-shrink-0">
      <div className="flex items-center justify-between px-5 pt-2 pb-1.5 text-[11px] font-bold bg-[#1a3d1a] text-white">
        <span>9:41</span>
        <div className="flex items-center gap-1.5">
          {isOffline ? <WifiOff size={11} className="text-[#f5c47c]" /> : <Wifi size={11} />}
          <Battery size={11} />
        </div>
      </div>
      {isOffline && (
        <div className="flex items-center gap-2 bg-[#7a5800]/90 px-4 py-1.5">
          <WifiOff size={11} className="text-[#f5c47c] flex-shrink-0" />
          <span className="text-[10px] font-bold text-[#f5c47c]">Offline Mode Active — Limited functionality available</span>
        </div>
      )}
    </div>
  );
}

// ─── BOTTOM NAV ──────────────────────────────────────────────────────────────

function BottomNav({ screen, navigate }: { screen: Screen; navigate: (s: Screen) => void }) {
  const isActive = (ids: Screen[]) => ids.includes(screen);

  return (
    <div className="flex items-end bg-card border-t border-border px-1 pt-1 pb-2 flex-shrink-0">
      <NavBtn active={isActive(["home"])} label="Home" icon={<Home size={20} />} onClick={() => navigate("home")} />
      <NavBtn active={isActive(["textTranslation"])} label="Translate" icon={<Languages size={20} />} onClick={() => navigate("textTranslation")} />
      <div className="flex flex-col items-center flex-1 -mt-6">
        <button
          onClick={() => navigate("speech")}
          className={`w-14 h-14 rounded-full flex items-center justify-center shadow-xl border-4 border-background transition-colors ${
            isActive(["speech", "translation", "tts"]) ? "bg-accent" : "bg-primary"
          }`}
        >
          <Mic size={22} className="text-white" />
        </button>
        <span className={`text-[9px] mt-0.5 font-bold ${isActive(["speech", "translation", "tts"]) ? "text-accent" : "text-muted-foreground"}`}>
          Speech
        </span>
      </div>
      <NavBtn active={isActive(["dictionary"])} label="Dictionary" icon={<BookOpen size={20} />} onClick={() => navigate("dictionary")} />
      <NavBtn active={isActive(["settings", "history"])} label="More" icon={<Settings size={20} />} onClick={() => navigate("settings")} />
    </div>
  );
}

function NavBtn({ active, label, icon, onClick }: { active: boolean; label: string; icon: React.ReactNode; onClick: () => void }) {
  return (
    <button onClick={onClick} className={`flex-1 flex flex-col items-center gap-0.5 py-1 rounded-xl transition-colors ${active ? "text-primary" : "text-muted-foreground"}`}>
      {icon}
      <span className="text-[9px] font-bold">{label}</span>
    </button>
  );
}

// ─── SPLASH SCREEN ───────────────────────────────────────────────────────────

function SplashScreen({ onDone }: { onDone: () => void }) {
  useEffect(() => {
    const t = setTimeout(onDone, 2900);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <div className="relative flex flex-col items-center justify-center h-full bg-[#1e4d1e] overflow-hidden text-white">
      <CulturalPattern opacity={0.14} patternId="dp-splash" />
      <div className="relative z-10 flex flex-col items-center gap-7 px-8 text-center">
        <motion.div
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.65, ease: [0.34, 1.56, 0.64, 1] }}
          className="w-28 h-28 rounded-[2rem] bg-white/15 backdrop-blur border border-white/25 flex items-center justify-center shadow-2xl"
        >
          <div className="flex items-center gap-1.5">
            <Mic size={32} className="text-white" />
            <Globe size={24} className="text-[#f5c47c]" />
          </div>
        </motion.div>
        <motion.div initial={{ y: 24, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.35, duration: 0.55 }}>
          <h1 className="text-[26px] font-extrabold leading-tight tracking-tight">
            Dumagat Speech<br />Translator
          </h1>
          <p className="text-white/65 text-sm mt-2.5 leading-relaxed">
            Preserving Indigenous Language<br />Through Technology
          </p>
        </motion.div>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }}
          className="w-52 h-1.5 bg-white/15 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: "0%" }} animate={{ width: "100%" }}
            transition={{ delay: 0.85, duration: 1.9, ease: "easeInOut" }}
            className="h-full bg-[#f5c47c] rounded-full"
          />
        </motion.div>
      </div>
      <div className="absolute bottom-0 left-0 w-40 h-40 rounded-full bg-white/5 -translate-x-1/3 translate-y-1/3" />
      <div className="absolute bottom-0 right-0 w-56 h-56 rounded-full bg-white/5 translate-x-1/3 translate-y-1/3" />
      <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.1 }}
        className="absolute bottom-10 text-white/35 text-xs font-medium">
        Bulos Language Preservation Initiative
      </motion.p>
    </div>
  );
}

// ─── HOME SCREEN ─────────────────────────────────────────────────────────────

function HomeScreen({ navigate, isOffline }: { navigate: (s: Screen) => void; isOffline: boolean }) {
  const cards = [
    { label: "Speech Translation", icon: Mic, screen: "speech" as Screen, bg: "bg-primary", fg: "text-white", desc: "Speak & translate", isPrimary: true },
    { label: "Text Translation", icon: Languages, screen: "textTranslation" as Screen, bg: "bg-[#f5c47c]/25", fg: "text-[#7a5a00]", desc: "Type & translate", isPrimary: false },
    { label: "Dictionary", icon: BookOpen, screen: "dictionary" as Screen, bg: "bg-[#e8d5b0]/70", fg: "text-[#5c3d1a]", desc: "Browse Bulos words", isPrimary: false },
    { label: "Translation History", icon: Clock, screen: "history" as Screen, bg: "bg-[#d4e8c2]/70", fg: "text-[#2d5a27]", desc: "Past translations", isPrimary: false },
  ];

  return (
    <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
      {/* Header */}
      <div className="relative bg-primary px-5 pt-5 pb-10 overflow-hidden">
        <CulturalPattern opacity={0.08} patternId="dp-home" />
        <div className="relative z-10 flex items-start justify-between">
          <div>
            <p className="text-white/65 text-xs font-semibold uppercase tracking-widest">Welcome</p>
            <h1 className="text-white text-xl font-extrabold mt-0.5">Dumagat Speech Translator</h1>
            <span className="inline-block mt-1 text-[10px] font-bold text-white/60 bg-white/10 px-2.5 py-0.5 rounded-full">Bulos · Filipino · English</span>
          </div>
          {isOffline && (
            <div className="flex items-center gap-1 bg-[#f5c47c]/20 border border-[#f5c47c]/40 px-2.5 py-1.5 rounded-xl mt-1">
              <WifiOff size={12} className="text-[#f5c47c]" />
              <span className="text-[10px] font-bold text-[#f5c47c]">Offline</span>
            </div>
          )}
        </div>
      </div>

      {/* Feature cards */}
      <div className="px-4 -mt-6 relative z-10">
        <div className="grid grid-cols-2 gap-3">
          {cards.map((card) => {
            const Icon = card.icon;
            return (
              <button key={card.label} onClick={() => navigate(card.screen)}
                className={`${card.bg} rounded-2xl p-4 text-left flex flex-col gap-2.5 shadow-sm border border-black/5 active:scale-95 transition-transform`}>
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${card.isPrimary ? "bg-white/20" : "bg-white/80"}`}>
                  <Icon size={17} className={card.isPrimary ? "text-white" : card.fg} />
                </div>
                <div>
                  <p className={`text-xs font-bold leading-tight ${card.fg}`}>{card.label}</p>
                  <p className={`text-[10px] mt-0.5 ${card.isPrimary ? "text-white/65" : "text-muted-foreground"}`}>{card.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Language support banner */}
      <div className="px-4 mt-5">
        <div className="bg-card rounded-2xl border border-border p-4 shadow-sm">
          <p className="text-[10px] font-extrabold text-muted-foreground uppercase tracking-widest mb-3">Supported Languages</p>
          <div className="flex items-center gap-3">
            {LANGS.map((l, i) => (
              <div key={l} className="flex items-center gap-2">
                <span className={`text-sm font-extrabold ${i === 0 ? "text-primary" : "text-foreground"}`}>{l}</span>
                {i < LANGS.length - 1 && <span className="text-muted-foreground/40 text-xs">·</span>}
              </div>
            ))}
          </div>
          <p className="text-[10px] text-muted-foreground mt-2">Translate between Bulos, Filipino, and English seamlessly</p>
        </div>
      </div>

      {/* Word of the day */}
      <div className="px-4 mt-3 mb-6">
        <div className="bg-[#2E5D2E] rounded-2xl p-4 relative overflow-hidden">
          <CulturalPattern opacity={0.1} patternId="dp-wotd" />
          <div className="relative z-10">
            <p className="text-[10px] font-bold text-white/60 uppercase tracking-widest">Bulos Word of the Day</p>
            <p className="text-2xl font-extrabold text-white mt-1">Danum</p>
            <p className="text-white/70 text-xs mt-0.5">Water · Tubig</p>
            <div className="flex items-center gap-2 mt-3">
              <button className="flex items-center gap-1.5 bg-white/20 text-white text-xs font-bold px-3 py-1.5 rounded-lg">
                <Volume2 size={12} />Listen
              </button>
              <button onClick={() => navigate("dictionary")} className="flex items-center gap-1.5 bg-white/10 text-white/80 text-xs font-bold px-3 py-1.5 rounded-lg">
                <BookOpen size={12} />More Words
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── SPEECH SCREEN ───────────────────────────────────────────────────────────

function SpeechScreen({ navigate, isOffline }: { navigate: (s: Screen) => void; isOffline: boolean }) {
  const [isListening, setIsListening] = useState(false);
  const [isDone, setIsDone] = useState(false);
  const [fromLang, setFromLang] = useState("Bulos");
  const [toLang, setToLang] = useState("Filipino");
  const [transcribedText, setTranscribedText] = useState("");
  const [isEditing, setIsEditing] = useState(false);

  const swap = () => { const t = fromLang; setFromLang(toLang); setToLang(t); };

  const handleMic = () => {
    if (isOffline) return;
    if (isListening) {
      setIsListening(false);
      setIsDone(true);
      setTranscribedText("Danum ang buhay ng lahat ng nilalang.");
    } else {
      setIsListening(true);
      setIsDone(false);
      setTranscribedText("");
      setIsEditing(false);
      setTimeout(() => {
        setIsListening(false);
        setIsDone(true);
        setTranscribedText("Danum ang buhay ng lahat ng nilalang.");
      }, 3000);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto flex flex-col" style={{ scrollbarWidth: "none" }}>
      <div className="bg-primary px-5 py-4 flex-shrink-0">
        <h1 className="text-white text-lg font-extrabold">Speech Recognition</h1>
        <p className="text-white/60 text-xs mt-0.5">Speak clearly — recognized text is editable</p>
      </div>

      {isOffline && (
        <div className="flex items-center gap-2 bg-[#7a5800]/15 border-b border-[#C17A3C]/20 px-4 py-2">
          <WifiOff size={12} className="text-[#C17A3C]" />
          <span className="text-[10px] font-bold text-[#C17A3C]">Speech recognition requires an internet connection</span>
        </div>
      )}

      <div className="flex-1 px-4 py-4 flex flex-col gap-4 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
        {/* Language selector */}
        <div className="bg-card rounded-2xl border border-border shadow-sm flex items-center overflow-hidden">
          <select value={fromLang} onChange={e => setFromLang(e.target.value)}
            className="flex-1 text-sm font-bold text-foreground bg-transparent px-4 py-3 appearance-none text-center border-r border-border outline-none">
            {LANGS.map(l => <option key={l}>{l}</option>)}
          </select>
          <button onClick={swap} className="px-3 text-muted-foreground hover:text-primary transition-colors">
            <ArrowLeftRight size={16} />
          </button>
          <select value={toLang} onChange={e => setToLang(e.target.value)}
            className="flex-1 text-sm font-bold text-foreground bg-transparent px-4 py-3 appearance-none text-center border-l border-border outline-none">
            {LANGS.map(l => <option key={l}>{l}</option>)}
          </select>
        </div>

        {/* Mic area */}
        <div className="flex flex-col items-center py-3 gap-4">
          <div className="relative flex items-center justify-center w-36 h-36">
            {isListening && (
              <>
                <motion.div animate={{ scale: [1, 1.45], opacity: [0.35, 0] }} transition={{ duration: 1.4, repeat: Infinity }}
                  className="absolute inset-0 rounded-full bg-red-400" />
                <motion.div animate={{ scale: [1, 1.8], opacity: [0.18, 0] }} transition={{ duration: 1.4, repeat: Infinity, delay: 0.35 }}
                  className="absolute inset-0 rounded-full bg-red-400" />
              </>
            )}
            <button onClick={handleMic}
              disabled={isOffline}
              className={`relative w-28 h-28 rounded-full flex items-center justify-center shadow-2xl transition-colors ${
                isOffline ? "bg-muted-foreground/30" : isListening ? "bg-red-500" : isDone ? "bg-accent" : "bg-primary"
              }`}>
              <Mic size={40} className="text-white" />
            </button>
          </div>

          <p className={`text-sm font-bold text-center ${isOffline ? "text-muted-foreground" : isListening ? "text-red-500" : isDone ? "text-accent" : "text-muted-foreground"}`}>
            {isOffline ? "Offline — speech unavailable" : isListening ? "Listening... tap to stop" : isDone ? "Done! Edit text below if needed" : "Tap to start recording"}
          </p>

          <div className="flex items-center gap-0.5 h-10" style={{ opacity: isListening ? 1 : 0.18 }}>
            {WAVE_HEIGHTS.map((h, i) => (
              <motion.div key={i}
                animate={isListening ? { scaleY: [1, 0.25, 1] } : { scaleY: 0.25 }}
                transition={isListening ? { duration: 0.55, repeat: Infinity, delay: i * 0.035 } : {}}
                style={{ height: h, transformOrigin: "center" }}
                className={`w-1 rounded-full ${isListening ? "bg-red-400" : "bg-muted-foreground/40"}`}
              />
            ))}
          </div>
        </div>

        {/* Editable transcription area */}
        <div className={`bg-card rounded-2xl border shadow-sm ${isEditing ? "border-primary ring-2 ring-primary/20" : "border-border"}`}>
          <div className="flex items-center justify-between px-4 pt-3.5 pb-2">
            <p className="text-[10px] font-extrabold text-muted-foreground uppercase tracking-widest">
              Recognized Text · {fromLang}
            </p>
            {isDone && (
              <button onClick={() => setIsEditing(!isEditing)}
                className={`text-[10px] font-bold px-2.5 py-1 rounded-lg transition-colors ${isEditing ? "bg-primary text-white" : "bg-muted text-primary"}`}>
                {isEditing ? "Done Editing" : "Edit"}
              </button>
            )}
          </div>
          <div className="px-4 pb-4">
            {isListening ? (
              <div className="flex items-center gap-1.5">
                {[0, 1, 2].map(i => (
                  <motion.div key={i} animate={{ opacity: [0.3, 1, 0.3] }} transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.2 }}
                    className="w-2 h-2 rounded-full bg-red-400" />
                ))}
                <span className="text-xs text-muted-foreground ml-1">Transcribing...</span>
              </div>
            ) : isDone ? (
              <textarea
                value={transcribedText}
                onChange={e => setTranscribedText(e.target.value)}
                readOnly={!isEditing}
                rows={3}
                className={`w-full bg-transparent text-sm font-semibold text-foreground resize-none outline-none leading-relaxed ${
                  isEditing ? "" : "cursor-default"
                }`}
              />
            ) : (
              <p className="text-sm text-muted-foreground italic">Your speech will appear here as editable text...</p>
            )}
          </div>
          {isEditing && (
            <div className="px-4 pb-3 flex items-center gap-1.5">
              <AlertCircle size={11} className="text-accent" />
              <p className="text-[10px] text-accent font-semibold">You can correct any recognition errors before translating</p>
            </div>
          )}
        </div>

        {/* Confidence score */}
        {isDone && (
          <div className="flex items-center gap-2 bg-[#e8f5e8] border border-primary/20 rounded-xl px-4 py-2.5">
            <Zap size={14} className="text-primary" />
            <span className="text-xs text-primary font-bold">Confidence Score: 92.4% · High Accuracy</span>
          </div>
        )}

        {/* Action buttons */}
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => isDone && transcribedText.trim() && navigate("translation")}
            className={`py-3.5 rounded-xl text-sm font-extrabold transition-all ${isDone && transcribedText.trim() ? "bg-primary text-white shadow-sm active:scale-95" : "bg-muted text-muted-foreground"}`}>
            Translate
          </button>
          <button onClick={() => { setIsDone(false); setIsListening(false); setTranscribedText(""); setIsEditing(false); }}
            className="py-3.5 rounded-xl text-sm font-extrabold bg-muted text-muted-foreground active:scale-95 transition-transform">
            Clear
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── TRANSLATION RESULT SCREEN ───────────────────────────────────────────────

function TranslationScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [copied, setCopied] = useState(false);

  return (
    <div className="flex-1 overflow-y-auto flex flex-col" style={{ scrollbarWidth: "none" }}>
      <div className="bg-primary px-5 py-4 flex items-center gap-3 flex-shrink-0">
        <button onClick={() => navigate("speech")} className="text-white/80"><ArrowLeft size={20} /></button>
        <h1 className="text-white text-lg font-extrabold">Translation Result</h1>
      </div>

      <div className="flex-1 px-4 py-4 flex flex-col gap-4 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
        <div className="flex items-center gap-2 bg-[#e8f5e8] border border-primary/20 rounded-xl px-4 py-2.5">
          <Zap size={14} className="text-primary" />
          <span className="text-xs text-primary font-bold">Confidence: 92.4% · High Accuracy</span>
        </div>

        {/* Source */}
        <div className="bg-card rounded-2xl border border-border shadow-sm p-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-extrabold text-muted-foreground uppercase tracking-widest">BULOS (Original)</span>
            <button onClick={() => navigate("tts")} className="p-1.5 bg-primary/10 rounded-lg">
              <Volume2 size={13} className="text-primary" />
            </button>
          </div>
          <p className="text-base font-bold text-foreground leading-relaxed">"Danum ang buhay ng lahat ng nilalang."</p>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-3">
          <div className="flex-1 h-px bg-border" />
          <span className="text-[10px] font-extrabold text-muted-foreground bg-muted px-3 py-1 rounded-full">Bulos → Filipino</span>
          <div className="flex-1 h-px bg-border" />
        </div>

        {/* Result */}
        <div className="bg-primary/8 rounded-2xl border-2 border-primary/25 shadow-sm p-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-extrabold text-primary uppercase tracking-widest">FILIPINO (Translation)</span>
            <button onClick={() => navigate("tts")} className="p-1.5 bg-primary/15 rounded-lg">
              <Volume2 size={13} className="text-primary" />
            </button>
          </div>
          <p className="text-base font-bold text-foreground leading-relaxed">"Ang tubig ay buhay ng lahat ng nilalang."</p>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => { setCopied(true); setTimeout(() => setCopied(false), 1500); }}
            className="flex items-center justify-center gap-2 py-3 rounded-xl bg-card border border-border text-sm font-bold active:scale-95 transition-transform">
            {copied ? <Check size={15} className="text-primary" /> : <Copy size={15} />}
            {copied ? "Copied!" : "Copy"}
          </button>
          <button className="flex items-center justify-center gap-2 py-3 rounded-xl bg-card border border-border text-sm font-bold active:scale-95 transition-transform">
            <Share2 size={15} />Share
          </button>
          <button onClick={() => navigate("tts")}
            className="flex items-center justify-center gap-2 py-3 rounded-xl bg-accent/15 border border-accent/25 text-accent text-sm font-bold active:scale-95 transition-transform">
            <Volume2 size={15} />Speak
          </button>
          <button onClick={() => navigate("speech")}
            className="flex items-center justify-center gap-2 py-3 rounded-xl bg-primary text-white text-sm font-bold active:scale-95 transition-transform">
            <RefreshCw size={15} />Translate Again
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── TEXT TRANSLATION SCREEN ─────────────────────────────────────────────────

function TextTranslationScreen({ isOffline }: { isOffline: boolean }) {
  const [fromLang, setFromLang] = useState("Bulos");
  const [toLang, setToLang] = useState("Filipino");
  const [inputText, setInputText] = useState("");
  const [translated, setTranslated] = useState("");
  const [loading, setLoading] = useState(false);
  const maxChars = 500;

  const handleTranslate = () => {
    if (!inputText.trim() || isOffline) return;
    setLoading(true);
    setTranslated("");
    setTimeout(() => {
      setTranslated("Ang tubig ay buhay ng lahat ng nilalang sa ating mundo.");
      setLoading(false);
    }, 1300);
  };

  const swap = () => {
    const tmp = fromLang; setFromLang(toLang); setToLang(tmp);
    const tmpT = inputText; setInputText(translated); setTranslated(tmpT);
  };

  return (
    <div className="flex-1 overflow-y-auto flex flex-col" style={{ scrollbarWidth: "none" }}>
      <div className="bg-primary px-5 py-4 flex-shrink-0">
        <h1 className="text-white text-lg font-extrabold">Text Translation</h1>
        <p className="text-white/60 text-xs mt-0.5">Type in any supported language</p>
      </div>

      {isOffline && (
        <div className="flex items-center gap-2 bg-[#7a5800]/15 border-b border-[#C17A3C]/20 px-4 py-2 flex-shrink-0">
          <WifiOff size={12} className="text-[#C17A3C]" />
          <span className="text-[10px] font-bold text-[#C17A3C]">Translation requires an internet connection</span>
        </div>
      )}

      <div className="flex-1 px-4 py-4 flex flex-col gap-4 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
        {/* Language selector */}
        <div className="bg-card rounded-2xl border border-border shadow-sm flex items-center overflow-hidden">
          <select value={fromLang} onChange={e => setFromLang(e.target.value)}
            className="flex-1 text-sm font-bold text-foreground bg-transparent px-4 py-3.5 appearance-none text-center outline-none">
            {LANGS.map(l => <option key={l}>{l}</option>)}
          </select>
          <button onClick={swap} className="px-4 py-3.5 text-muted-foreground hover:text-primary transition-colors">
            <ArrowLeftRight size={18} />
          </button>
          <select value={toLang} onChange={e => setToLang(e.target.value)}
            className="flex-1 text-sm font-bold text-foreground bg-transparent px-4 py-3.5 appearance-none text-center outline-none">
            {LANGS.map(l => <option key={l}>{l}</option>)}
          </select>
        </div>

        {/* Input */}
        <div className="bg-card rounded-2xl border border-border shadow-sm p-4">
          <p className="text-[10px] font-extrabold text-muted-foreground uppercase tracking-widest mb-2">{fromLang}</p>
          <textarea value={inputText} onChange={e => setInputText(e.target.value.slice(0, maxChars))}
            placeholder={`Enter text in ${fromLang}...`} rows={4}
            className="w-full bg-transparent text-sm text-foreground resize-none outline-none placeholder:text-muted-foreground/70 leading-relaxed" />
          <div className="flex items-center justify-between mt-2 pt-2 border-t border-border">
            <span className={`text-[10px] font-semibold ${inputText.length > maxChars * 0.9 ? "text-destructive" : "text-muted-foreground"}`}>
              {inputText.length} / {maxChars}
            </span>
            {inputText && (
              <button onClick={() => { setInputText(""); setTranslated(""); }}
                className="text-[10px] font-bold text-muted-foreground hover:text-foreground transition-colors">Clear</button>
            )}
          </div>
        </div>

        <button onClick={handleTranslate} disabled={!inputText.trim() || loading || isOffline}
          className={`py-4 rounded-xl text-sm font-extrabold transition-all ${
            inputText.trim() && !loading && !isOffline ? "bg-primary text-white shadow-sm active:scale-95" : "bg-muted text-muted-foreground"
          }`}>
          {loading ? "Translating..." : isOffline ? "Offline — Translation unavailable" : `Translate to ${toLang}`}
        </button>

        {(translated || loading) && (
          <div className="bg-primary/8 rounded-2xl border-2 border-primary/25 p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] font-extrabold text-primary uppercase tracking-widest">{toLang}</span>
              {translated && (
                <div className="flex items-center gap-1.5">
                  <button className="p-1.5 bg-primary/12 rounded-lg"><Volume2 size={12} className="text-primary" /></button>
                  <button className="p-1.5 bg-primary/12 rounded-lg"><Copy size={12} className="text-primary" /></button>
                </div>
              )}
            </div>
            {loading ? (
              <div className="flex items-center gap-1.5 py-1">
                {[0, 1, 2].map(i => (
                  <motion.div key={i} animate={{ opacity: [0.3, 1, 0.3] }} transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.2 }}
                    className="w-2 h-2 rounded-full bg-primary" />
                ))}
                <span className="text-xs text-muted-foreground ml-1">Processing...</span>
              </div>
            ) : (
              <p className="text-sm font-bold text-foreground leading-relaxed">{translated}</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── TTS SCREEN ──────────────────────────────────────────────────────────────

function TTSScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [speed, setSpeed] = useState(1.0);
  const [voice, setVoice] = useState("Bulos Female");
  const voices = ["Bulos Female", "Bulos Male", "Filipino Female", "Filipino Male"];

  useEffect(() => {
    if (!playing) return;
    const interval = setInterval(() => {
      setProgress(p => { if (p >= 100) { setPlaying(false); return 0; } return p + 2; });
    }, 80);
    return () => clearInterval(interval);
  }, [playing]);

  return (
    <div className="flex-1 overflow-y-auto flex flex-col" style={{ scrollbarWidth: "none" }}>
      <div className="bg-primary px-5 py-4 flex items-center gap-3 flex-shrink-0">
        <button onClick={() => navigate("translation")} className="text-white/80"><ArrowLeft size={20} /></button>
        <h1 className="text-white text-lg font-extrabold">Text-to-Speech</h1>
      </div>

      <div className="flex-1 px-4 py-5 flex flex-col items-center gap-5 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
        <div className="relative w-32 h-32 flex items-center justify-center">
          <div className="w-28 h-28 rounded-full bg-primary/12 flex items-center justify-center">
            <Volume2 size={52} className="text-primary" />
          </div>
          {playing && (
            <>
              <motion.div animate={{ scale: [1, 1.35], opacity: [0.35, 0] }} transition={{ duration: 1, repeat: Infinity }}
                className="absolute inset-0 rounded-full border-2 border-primary" />
              <motion.div animate={{ scale: [1, 1.65], opacity: [0.18, 0] }} transition={{ duration: 1, repeat: Infinity, delay: 0.35 }}
                className="absolute inset-0 rounded-full border-2 border-primary" />
            </>
          )}
        </div>

        <div className="bg-card rounded-2xl border border-border p-4 w-full text-center shadow-sm">
          <p className="text-xs font-extrabold text-primary mb-1">BULOS</p>
          <p className="text-sm font-bold text-foreground leading-relaxed">Danum ang buhay ng lahat ng nilalang.</p>
          <p className="text-xs text-muted-foreground mt-1.5">Ang tubig ay buhay ng lahat ng nilalang.</p>
        </div>

        <div className="flex items-center gap-0.5 w-full justify-center py-1">
          {WAVE_HEIGHTS.map((h, i) => (
            <motion.div key={i}
              animate={playing ? { scaleY: [1, 0.25, 1] } : { scaleY: 0.3 }}
              transition={playing ? { duration: 0.5, repeat: Infinity, delay: i * 0.04 } : { duration: 0.3 }}
              style={{ height: h, transformOrigin: "center" }}
              className={`w-1.5 rounded-full transition-colors ${playing ? "bg-primary" : "bg-muted-foreground/25"}`}
            />
          ))}
        </div>

        <div className="w-full">
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${progress}%` }} />
          </div>
          <div className="flex justify-between mt-1.5">
            <span className="text-[10px] font-semibold text-muted-foreground">{(progress * 0.05).toFixed(1)}s</span>
            <span className="text-[10px] font-semibold text-muted-foreground">5.0s</span>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <button onClick={() => setProgress(0)} className="w-11 h-11 rounded-full bg-muted flex items-center justify-center text-muted-foreground active:scale-90 transition-transform">
            <RefreshCw size={18} />
          </button>
          <button onClick={() => setPlaying(!playing)}
            className="w-16 h-16 rounded-full bg-primary flex items-center justify-center shadow-xl active:scale-95 transition-transform">
            {playing ? <Pause size={26} className="text-white" /> : <Play size={26} className="text-white" />}
          </button>
          <button onClick={() => { setPlaying(false); setProgress(0); }} className="w-11 h-11 rounded-full bg-muted flex items-center justify-center text-muted-foreground active:scale-90 transition-transform">
            <Square size={18} />
          </button>
        </div>

        <div className="bg-card rounded-2xl border border-border p-4 w-full shadow-sm">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-extrabold text-foreground">Playback Speed</span>
            <span className="text-sm font-extrabold text-primary">{speed.toFixed(1)}×</span>
          </div>
          <input type="range" min={0.5} max={2} step={0.1} value={speed} onChange={e => setSpeed(parseFloat(e.target.value))} className="w-full accent-[#2e5d2e]" />
          <div className="flex justify-between mt-1"><span className="text-[10px] font-semibold text-muted-foreground">0.5×</span><span className="text-[10px] font-semibold text-muted-foreground">2.0×</span></div>
        </div>

        <div className="bg-card rounded-2xl border border-border p-4 w-full shadow-sm">
          <p className="text-sm font-extrabold text-foreground mb-3">Voice</p>
          <div className="grid grid-cols-2 gap-2">
            {voices.map(v => (
              <button key={v} onClick={() => setVoice(v)}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold text-left transition-colors active:scale-95 ${voice === v ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>
                {v}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── DICTIONARY SCREEN ───────────────────────────────────────────────────────

function DictionaryScreen() {
  const [search, setSearch] = useState("");
  const [expanded, setExpanded] = useState<number | null>(null);
  const [alpha, setAlpha] = useState("All");
  const letters = ["All", "A", "B", "D", "G", "I", "L", "M", "S", "U"];

  const filtered = WORDS.filter(w => {
    const matchAlpha = alpha === "All" || w.bulos.startsWith(alpha);
    const q = search.toLowerCase();
    return matchAlpha && (!search || w.bulos.toLowerCase().includes(q) || w.filipino.toLowerCase().includes(q) || w.english.toLowerCase().includes(q));
  });

  return (
    <div className="flex-1 overflow-y-auto flex flex-col" style={{ scrollbarWidth: "none" }}>
      <div className="bg-primary px-5 py-4 flex-shrink-0">
        <h1 className="text-white text-lg font-extrabold">Bulos Dictionary</h1>
        <p className="text-white/60 text-xs mt-0.5">{WORDS.length} words · Bulos · Filipino · English</p>
      </div>

      <div className="px-4 py-3 bg-card border-b border-border flex-shrink-0">
        <div className="flex items-center gap-2 bg-muted rounded-xl px-3 py-2.5">
          <Search size={15} className="text-muted-foreground flex-shrink-0" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search Bulos, Filipino, or English..."
            className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground/70 min-w-0" />
          {search && <button onClick={() => setSearch("")}><X size={14} className="text-muted-foreground" /></button>}
        </div>
      </div>

      <div className="px-4 py-2.5 border-b border-border flex-shrink-0 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
        <div className="flex gap-1.5 min-w-max">
          {letters.map(l => (
            <button key={l} onClick={() => setAlpha(l)}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-colors ${alpha === l ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>
              {l}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-3 flex flex-col gap-2" style={{ scrollbarWidth: "none" }}>
        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <BookOpen size={40} className="mb-3 opacity-25" />
            <p className="text-sm font-bold">No words found</p>
            <p className="text-xs mt-1 opacity-70">Try a different search term</p>
          </div>
        )}
        {filtered.map(word => (
          <div key={word.id} className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden">
            <div onClick={() => setExpanded(expanded === word.id ? null : word.id)}
              className="w-full flex items-center justify-between px-4 py-3.5 cursor-pointer select-none">
              <div className="text-left">
                <p className="text-sm font-extrabold text-foreground">{word.bulos}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{word.english} · <span className="text-primary/70">{word.filipino}</span></p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button className="p-1.5 bg-primary/10 rounded-lg" onClick={e => e.stopPropagation()}>
                  <Volume2 size={13} className="text-primary" />
                </button>
                <ChevronDown size={15} className={`text-muted-foreground transition-transform duration-200 ${expanded === word.id ? "rotate-180" : ""}`} />
              </div>
            </div>
            {expanded === word.id && (
              <div className="px-4 pb-4 border-t border-border pt-3 space-y-3">
                <div>
                  <p className="text-[9px] font-extrabold text-muted-foreground uppercase tracking-widest">Pronunciation</p>
                  <p className="text-sm font-mono font-bold text-primary mt-0.5">[{word.pronunciation}]</p>
                </div>
                <div>
                  <p className="text-[9px] font-extrabold text-muted-foreground uppercase tracking-widest">Filipino</p>
                  <p className="text-sm font-semibold text-foreground mt-0.5">{word.filipino}</p>
                </div>
                <div>
                  <p className="text-[9px] font-extrabold text-muted-foreground uppercase tracking-widest">Example Sentence</p>
                  <p className="text-sm italic text-foreground mt-0.5 leading-relaxed">"{word.example}"</p>
                  <p className="text-xs text-muted-foreground mt-1">{word.englishEx}</p>
                </div>
                <button className="flex items-center gap-2 text-xs text-white font-bold bg-primary px-4 py-2 rounded-xl">
                  <Volume2 size={12} />Hear Pronunciation
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── HISTORY SCREEN ──────────────────────────────────────────────────────────

function HistoryScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [search, setSearch] = useState("");
  const [items, setItems] = useState(HISTORY_INITIAL);

  const groups = items.reduce((acc, item) => {
    if (!acc[item.date]) acc[item.date] = [];
    acc[item.date].push(item);
    return acc;
  }, {} as Record<string, HistoryItem[]>);

  const filtered = Object.fromEntries(
    Object.entries(groups).map(([date, dateItems]) => [
      date,
      dateItems.filter(i =>
        !search || i.source.toLowerCase().includes(search.toLowerCase()) || i.result.toLowerCase().includes(search.toLowerCase())
      ),
    ]).filter(([, di]) => di.length > 0)
  );

  return (
    <div className="flex-1 overflow-y-auto flex flex-col" style={{ scrollbarWidth: "none" }}>
      <div className="bg-primary px-5 py-4 flex items-center gap-3 flex-shrink-0">
        <button onClick={() => navigate("home")} className="text-white/80"><ArrowLeft size={20} /></button>
        <div>
          <h1 className="text-white text-lg font-extrabold">Translation History</h1>
          <p className="text-white/60 text-xs">{items.length} translations stored locally</p>
        </div>
      </div>

      <div className="px-4 py-3 bg-card border-b border-border flex-shrink-0">
        <div className="flex items-center gap-2 bg-muted rounded-xl px-3 py-2.5">
          <Search size={15} className="text-muted-foreground flex-shrink-0" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search history..."
            className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground/70" />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-3 flex flex-col gap-5" style={{ scrollbarWidth: "none" }}>
        {Object.entries(filtered).map(([date, dateItems]) => (
          <div key={date}>
            <p className="text-[10px] font-extrabold text-muted-foreground uppercase tracking-widest mb-2.5">{date}</p>
            <div className="flex flex-col gap-2.5">
              {dateItems.map(item => (
                <div key={item.id} className="bg-card rounded-2xl border border-border shadow-sm p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[10px] font-extrabold text-primary bg-primary/10 px-2 py-0.5 rounded-full">
                        {item.from} → {item.to}
                      </span>
                      <span className="text-[10px] text-muted-foreground font-semibold">{item.time}</span>
                    </div>
                    <button onClick={() => setItems(prev => prev.filter(i => i.id !== item.id))} className="p-1.5 flex-shrink-0">
                      <Trash2 size={14} className="text-muted-foreground" />
                    </button>
                  </div>
                  <p className="text-sm font-bold text-foreground leading-snug">{item.source}</p>
                  <p className="text-xs text-muted-foreground mt-1 leading-snug">{item.result}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
        {Object.keys(filtered).length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <Clock size={40} className="mb-3 opacity-25" />
            <p className="text-sm font-bold">No history found</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── SETTINGS SCREEN ─────────────────────────────────────────────────────────

function SettingsScreen({ isOffline, setIsOffline }: {
  isOffline: boolean; setIsOffline: (v: boolean) => void;
}) {
  const [theme, setTheme] = useState("Light");
  const [fontSize, setFontSize] = useState("Medium");
  const [notifications, setNotifications] = useState(true);
  const [speechSpeed, setSpeechSpeed] = useState(1.0);

  function Toggle({ value, onChange }: { value: boolean; onChange: () => void }) {
    return (
      <button onClick={onChange} className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${value ? "bg-primary" : "bg-muted-foreground/30"}`}>
        <span className="absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all duration-200" style={{ left: value ? "22px" : "2px" }} />
      </button>
    );
  }

  function GroupLabel({ label }: { label: string }) {
    return <p className="text-[10px] font-extrabold text-muted-foreground uppercase tracking-widest mb-2 px-1">{label}</p>;
  }

  return (
    <div className="flex-1 overflow-y-auto flex flex-col" style={{ scrollbarWidth: "none" }}>
      <div className="bg-primary px-5 py-4 flex-shrink-0">
        <h1 className="text-white text-lg font-extrabold">Settings</h1>
        <p className="text-white/60 text-xs mt-0.5">Customize your experience</p>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-5" style={{ scrollbarWidth: "none" }}>
        {/* Network / Offline */}
        <div>
          <GroupLabel label="Network" />
          <div className={`rounded-2xl border shadow-sm overflow-hidden ${isOffline ? "bg-[#7a5800]/10 border-[#C17A3C]/25" : "bg-card border-border"}`}>
            <div className="flex items-center justify-between px-4 py-4">
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${isOffline ? "bg-[#C17A3C]/20" : "bg-primary/10"}`}>
                  {isOffline ? <WifiOff size={16} className="text-[#C17A3C]" /> : <Wifi size={16} className="text-primary" />}
                </div>
                <div>
                  <p className="text-sm font-extrabold text-foreground">Offline Mode</p>
                  <p className="text-xs text-muted-foreground">{isOffline ? "Active — using cached data" : "Disabled — using live AI"}</p>
                </div>
              </div>
              <Toggle value={isOffline} onChange={() => setIsOffline(!isOffline)} />
            </div>
            {isOffline && (
              <div className="px-4 pb-3 pt-0">
                <div className="bg-[#C17A3C]/12 rounded-xl px-3 py-2.5">
                  <p className="text-[10px] font-bold text-[#8B5E00] leading-relaxed">
                    Offline mode uses cached dictionary and translations. Speech recognition and live translation are unavailable.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Appearance */}
        <div>
          <GroupLabel label="Appearance" />
          <div className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-4 py-4 border-b border-border">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center"><Sun size={16} className="text-primary" /></div>
                <div>
                  <p className="text-sm font-extrabold text-foreground">Theme</p>
                  <p className="text-xs text-muted-foreground">{theme}</p>
                </div>
              </div>
              <div className="flex gap-1">
                {["Light", "Dark", "System"].map(t => (
                  <button key={t} onClick={() => setTheme(t)}
                    className={`text-[10px] font-extrabold px-2.5 py-1 rounded-lg transition-colors ${theme === t ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center justify-between px-4 py-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center">
                  <span className="text-sm font-extrabold text-primary">Aa</span>
                </div>
                <div>
                  <p className="text-sm font-extrabold text-foreground">Font Size</p>
                  <p className="text-xs text-muted-foreground">{fontSize}</p>
                </div>
              </div>
              <div className="flex gap-1">
                {["Small", "Medium", "Large"].map(s => (
                  <button key={s} onClick={() => setFontSize(s)}
                    className={`text-[10px] font-extrabold px-2.5 py-1 rounded-lg transition-colors ${fontSize === s ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Speech */}
        <div>
          <GroupLabel label="Speech" />
          <div className="bg-card rounded-2xl border border-border shadow-sm p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center"><Volume2 size={16} className="text-primary" /></div>
                <p className="text-sm font-extrabold text-foreground">Speech Speed</p>
              </div>
              <span className="text-sm font-extrabold text-primary">{speechSpeed.toFixed(1)}×</span>
            </div>
            <input type="range" min={0.5} max={2} step={0.1} value={speechSpeed} onChange={e => setSpeechSpeed(parseFloat(e.target.value))} className="w-full accent-[#2e5d2e]" />
          </div>
        </div>

        {/* Notifications */}
        <div>
          <GroupLabel label="App" />
          <div className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-4 py-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center"><Bell size={16} className="text-primary" /></div>
                <div>
                  <p className="text-sm font-extrabold text-foreground">Notifications</p>
                  <p className="text-xs text-muted-foreground">Daily word & reminders</p>
                </div>
              </div>
              <Toggle value={notifications} onChange={() => setNotifications(!notifications)} />
            </div>
          </div>
        </div>

        {/* About */}
        <div>
          <GroupLabel label="About" />
          <div className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden">
            {[
              { icon: Info, label: "About", desc: "Version 2.0.0 · Bulos Edition" },
              { icon: Shield, label: "Privacy Policy", desc: "How we protect your data" },
              { icon: HelpCircle, label: "Help & Support", desc: "Get assistance" },
            ].map(({ icon: Icon, label, desc }, i, arr) => (
              <button key={label} className={`w-full flex items-center justify-between px-4 py-4 active:bg-muted/60 transition-colors ${i < arr.length - 1 ? "border-b border-border" : ""}`}>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center"><Icon size={16} className="text-primary" /></div>
                  <div className="text-left">
                    <p className="text-sm font-extrabold text-foreground">{label}</p>
                    <p className="text-xs text-muted-foreground">{desc}</p>
                  </div>
                </div>
                <ChevronRight size={16} className="text-muted-foreground" />
              </button>
            ))}
          </div>
        </div>

        <div className="text-center py-3">
          <p className="text-xs font-bold text-muted-foreground">Dumagat Speech Translator v2.0.0</p>
          <p className="text-[10px] text-muted-foreground/60 mt-1">Bulos · Filipino · English · Preserving Indigenous Language</p>
        </div>
      </div>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [isOffline, setIsOffline] = useState(false);

  const navigate = (s: Screen) => setScreen(s);

  const showNav = screen !== "splash";
  const showStatus = screen !== "splash";

  return (
    <div
      className="min-h-screen flex items-center justify-center py-6 px-4"
      style={{
        background: "radial-gradient(ellipse at 30% 20%, #1a3d1a 0%, #0d2211 40%, #0a1a0a 100%)",
        fontFamily: "'Nunito', 'Noto Sans', system-ui, sans-serif",
      }}
    >
      {/* Ambient background */}
      <div className="fixed inset-0 text-white pointer-events-none" style={{ opacity: 0.04 }}>
        <CulturalPattern opacity={1} patternId="dp-bg" />
      </div>

      {/* Phone frame */}
      <div
        className="relative flex flex-col overflow-hidden"
        style={{
          width: 390,
          height: 844,
          borderRadius: "3rem",
          background: "#111",
          boxShadow: "0 0 0 1px rgba(255,255,255,0.08), 0 32px 80px rgba(0,0,0,0.7), 0 8px 24px rgba(0,0,0,0.5)",
        }}
      >
        {/* Notch */}
        <div
          className="absolute top-0 left-1/2 -translate-x-1/2 z-30 flex items-center justify-center gap-1.5"
          style={{ width: 120, height: 32, background: "#111", borderRadius: "0 0 1.25rem 1.25rem" }}
        >
          <div className="w-2 h-2 rounded-full bg-[#1a1a1a] border border-[#333]" />
          <div className="w-3 h-3 rounded-full bg-[#1a1a1a] border border-[#333]" />
        </div>

        {/* Side buttons */}
        <div className="absolute right-0 top-28 w-1 h-16 bg-[#333] rounded-l-sm" style={{ marginRight: -1 }} />
        <div className="absolute left-0 top-20 w-1 h-10 bg-[#333] rounded-r-sm" style={{ marginLeft: -1 }} />
        <div className="absolute left-0 top-36 w-1 h-10 bg-[#333] rounded-r-sm" style={{ marginLeft: -1 }} />

        {/* Screen */}
        <div className="flex-1 flex flex-col overflow-hidden bg-background" style={{ marginTop: 32 }}>
          {showStatus && <StatusBar isOffline={isOffline} />}

          <motion.div
            key={screen}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="flex-1 flex flex-col overflow-hidden"
          >
            {screen === "splash" && <SplashScreen onDone={() => setScreen("home")} />}
            {screen === "home" && <HomeScreen navigate={navigate} isOffline={isOffline} />}
            {screen === "speech" && <SpeechScreen navigate={navigate} isOffline={isOffline} />}
            {screen === "translation" && <TranslationScreen navigate={navigate} />}
            {screen === "textTranslation" && <TextTranslationScreen isOffline={isOffline} />}
            {screen === "tts" && <TTSScreen navigate={navigate} />}
            {screen === "dictionary" && <DictionaryScreen />}
            {screen === "history" && <HistoryScreen navigate={navigate} />}
            {screen === "settings" && <SettingsScreen isOffline={isOffline} setIsOffline={setIsOffline} />}
          </motion.div>

          {showNav && !["splash", "translation", "tts"].includes(screen) && (
            <BottomNav screen={screen} navigate={navigate} />
          )}
        </div>
      </div>

      <div className="fixed bottom-4 left-0 right-0 text-center pointer-events-none">
        <p className="text-white/20 text-xs font-semibold">Dumagat Speech Translator v2.0 · Interactive Prototype</p>
      </div>
    </div>
  );
}
